from PyPDF2 import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from io import BytesIO
import os

def add_duck_watermark(input_pdf, output_pdf, duck_image_path, duck_metadata):
    # Create a watermark PDF with the duck image and metadata
    packet = BytesIO()
    can = canvas.Canvas(packet, pagesize=letter)
    can.drawImage(duck_image_path, 100, 400, width=120, height=120)
    can.setFont("Helvetica", 8)
    can.drawString(100, 390, duck_metadata)  # Optionally, visually encode metadata
    can.save()

    packet.seek(0)
    duck_pdf = PdfReader(packet)
    original = PdfReader(input_pdf)
    writer = PdfWriter()

    # Merge watermark on each page
    for i, page in enumerate(original.pages):
        page.merge_page(duck_pdf.pages[0])
        writer.add_page(page)

    # Add metadata to the PDF
    metadata = dict(original.metadata) if original.metadata else {}
    metadata["/DuckWatermark"] = duck_metadata
    writer.add_metadata(metadata)

    with open(output_pdf, "wb") as out_f:
        writer.write(out_f)
        
def verify_duck_watermark(pdf_path, expected_metadata):
    reader = PdfReader(pdf_path)
    duck_meta = reader.metadata.get("/DuckWatermark")
    return duck_meta == expected_metadata
