import os
from io import BytesIO
from PyPDF2 import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.utils import ImageReader
from PIL import Image

def gif_to_png_bytes(gif_path):
    """
    Convert GIF to PNG and return bytes (use first frame only).
    This is needed because ReportLab does not support GIF directly.
    """
    im = Image.open(gif_path)
    im = im.convert('RGBA')
    buf = BytesIO()
    im.save(buf, format='PNG')
    buf.seek(0)
    return buf

def add_gif_watermark(input_pdf, output_pdf, gif_image_path, watermark_metadata, opacity=0.10, size=(32, 32)):
    """
    Add a semi-transparent watermark GIF (converted to PNG) to the bottom-right margin of the PDF.
    Stores watermark metadata in the PDF's metadata.
    """
    # Convert GIF to PNG in memory
    buf = gif_to_png_bytes(gif_image_path)

    # Create watermark PDF with transparent GIF
    packet = BytesIO()
    can = canvas.Canvas(packet, pagesize=letter)
    # Place watermark outside text, bottom right corner
    x, y = letter[0] - size[0] - 18, 18  # 18pt margin from right and bottom
    can.saveState()
    can.translate(x, y)
    can.setFillAlpha(opacity)
    can.drawImage(ImageReader(buf), 0, 0, width=size[0], height=size[1], mask='auto')
    can.restoreState()
    can.setFont("Helvetica", 7)
    can.setFillAlpha(1.0)
    can.drawString(18, 12, watermark_metadata)  # Optionally, encode metadata visually (for debugging)
    can.save()

    packet.seek(0)
    gif_pdf = PdfReader(packet)
    original = PdfReader(input_pdf)
    writer = PdfWriter()

    # Overlay watermark on each page
    for page in original.pages:
        page.merge_page(gif_pdf.pages[0])
        writer.add_page(page)

    # Add watermark metadata
    meta = dict(original.metadata) if original.metadata else {}
    meta["/GifWatermark"] = watermark_metadata
    writer.add_metadata(meta)
    with open(output_pdf, "wb") as out_f:
        writer.write(out_f)

def verify_gif_watermark(pdf_path, expected_metadata):
    """
    Check if the given PDF contains the expected GIF watermark metadata.
    """
    reader = PdfReader(pdf_path)
    gif_meta = reader.metadata.get("/GifWatermark")
    return gif_meta == expected_metadata