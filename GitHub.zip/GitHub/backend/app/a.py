import os, base64

# Generate 16-byte random string (128 bits) for AES IV
iv = os.urandom(16)

# Convert to base64 to make it readable and compatible with systems that require base64
iv_base64 = base64.b64encode(iv).decode()

print(iv_base64)
