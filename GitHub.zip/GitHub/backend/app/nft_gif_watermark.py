# nft_gif_watermark.py
import requests
import json
import os
from pathlib import Path
from typing import Optional

IPFS_API_URL = "http://localhost:5001/api/v0"
GIPHY_API_KEY = "RgWdFm2znLL0nYNULLFqyEVErZocUEYp" 
GIPHY_RANDOM_URL = "https://api.giphy.com/v1/gifs/random"

def fetch_random_gif(tag: str = "emoji") -> Optional[bytes]:
    """Fetch a random GIF from GIPHY"""
    try:
        params = {
            "api_key": GIPHY_API_KEY,
            "tag": tag,
            "rating": "pg"
        }
        res = requests.get(GIPHY_RANDOM_URL, params=params, timeout=10)
        res.raise_for_status()
        gif_url = res.json()["data"]["images"]["downsized"]["url"]
        gif_bytes = requests.get(gif_url, timeout=10).content
        return gif_bytes
    except Exception as e:
        print(f"Error fetching GIF: {e}")
        return None

def upload_to_ipfs(content_bytes: bytes, filename: str = "watermark.gif") -> Optional[str]:
    """Upload content to IPFS"""
    try:
        files = {'file': (filename, content_bytes)}
        res = requests.post(f"{IPFS_API_URL}/add", files=files, timeout=30)
        res.raise_for_status()
        ipfs_hash = res.json()["Hash"]
        return f"https://ipfs.io/ipfs/{ipfs_hash}"
    except Exception as e:
        print(f"Error uploading to IPFS: {e}")
        return None

def create_nft_metadata(document_hash: str, gif_url: str) -> Optional[str]:
    """Create NFT metadata JSON and upload to IPFS"""
    try:
        metadata = {
            "name": "Emoji Watermark NFT",
            "description": "NFT watermark using GIF emoji",
            "image": gif_url,
            "attributes": [
                {"trait_type": "Document Hash", "value": document_hash}
            ]
        }
        metadata_bytes = json.dumps(metadata).encode()
        return upload_to_ipfs(metadata_bytes, "metadata.json")
    except Exception as e:
        print(f"Error creating metadata: {e}")
        return None

def test_workflow():
    """Test the complete workflow"""
    print("=== Testing NFT GIF Watermark ===")
    
    # Test GIF fetching
    print("\n1. Fetching random GIF...")
    gif_bytes = fetch_random_gif("duck")
    if not gif_bytes:
        print("Failed to fetch GIF")
        return
    
    # Save test GIF locally for verification
    test_dir = Path("test_output")
    test_dir.mkdir(exist_ok=True)
    gif_path = test_dir/"test.gif"
    with open(gif_path, "wb") as f:
        f.write(gif_bytes)
    print(f"Saved test GIF to {gif_path}")
    
    # Test IPFS upload
    print("\n2. Uploading GIF to IPFS...")
    gif_url = upload_to_ipfs(gif_bytes)
    if not gif_url:
        print("Failed to upload GIF to IPFS")
        return
    print(f"GIF IPFS URL: {gif_url}")
    
    # Test metadata creation
    print("\n3. Creating NFT metadata...")
    test_hash = "0x1234abcd"
    metadata_url = create_nft_metadata(test_hash, gif_url)
    if not metadata_url:
        print("Failed to create metadata")
        return
    print(f"Metadata IPFS URL: {metadata_url}")
    
    print("\n=== Test completed successfully ===")
    print(f"View GIF: {gif_url}")
    print(f"View metadata: {metadata_url}")

if __name__ == "__main__":
    test_workflow()