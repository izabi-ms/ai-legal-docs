import os
import json
import hashlib
import logging
from pathlib import Path
from typing import Optional
from web3 import Web3
from web3.exceptions import TransactionNotFound, ContractLogicError
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Logging configuration
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class BlockchainService:
    def __init__(self):
        try:
            # Load environment
            self.INFURA_URL = os.getenv("INFURA_URL")
            if not self.INFURA_URL:
                raise ValueError("INFURA_URL environment variable not set")
            self.web3 = Web3(Web3.HTTPProvider(self.INFURA_URL))
            if not self.web3.is_connected():
                raise ConnectionError("Failed to connect to Ethereum node")

            self.CONTRACT_ADDRESS = os.getenv("CONTRACT_ADDRESS")
            if not self.CONTRACT_ADDRESS:
                raise ValueError("CONTRACT_ADDRESS environment variable not set")

            self.ACCOUNT_ADDRESS = os.getenv("ACCOUNT_ADDRESS")
            if not self.ACCOUNT_ADDRESS:
                raise ValueError("ACCOUNT_ADDRESS environment variable not set")

            self.PRIVATE_KEY = os.getenv("PRIVATE_KEY")
            if not self.PRIVATE_KEY:
                raise ValueError("PRIVATE_KEY environment variable not set")

            # Load ABI
            abi_path = Path(__file__).parent / "contract_abi.json"
            try:
                with abi_path.open("r") as f:
                    self.CONTRACT_ABI = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load contract ABI: {e}")
                raise

            # Contract instance
            self.contract = self.web3.eth.contract(
                address=Web3.to_checksum_address(self.CONTRACT_ADDRESS),
                abi=self.CONTRACT_ABI
            )

            # Verify contract address
            self._verify_contract()

        except Exception as e:
            logger.error(f"BlockchainService initialization failed: {e}")
            raise

    def _verify_contract(self):
        """Ensure the address is a contract"""
        try:
            code = self.web3.eth.get_code(Web3.to_checksum_address(self.CONTRACT_ADDRESS))
            if code == b'':
                raise ValueError(f"Address {self.CONTRACT_ADDRESS} is not a contract")
            logger.info("✅ Contract verified successfully.")
        except Exception as e:
            logger.error(f"Contract verification failed: {e}")
            raise

    def hash_document(self, document: str) -> str:
        """Returns keccak256 hash of the document text (bytes32 hex string)"""
        return self.web3.keccak(text=document).hex()

    def notarize_hash_on_chain(self, doc_hash: str) -> str:
        """Sends the document hash to the contract's notarizeDocument() function"""
        try:
            # Convert to bytes32
            hash_bytes = self.web3.to_bytes(hexstr=doc_hash)

            # Build transaction
            txn = self.contract.functions.notarizeDocument(hash_bytes).build_transaction({
                'from': self.ACCOUNT_ADDRESS,
                'nonce': self.web3.eth.get_transaction_count(self.ACCOUNT_ADDRESS),
                'gas': 300000,
                'gasPrice': self.web3.to_wei('10', 'gwei')
            })

            # Sign and send
            signed_txn = self.web3.eth.account.sign_transaction(txn, private_key=self.PRIVATE_KEY)
            tx_hash = self.web3.eth.send_raw_transaction(signed_txn.rawTransaction)

            return self.web3.to_hex(tx_hash)

        except ContractLogicError as e:
            logger.error(f"Smart contract error: {e}")
            raise
        except Exception as e:
            logger.error(f"Transaction failed: {e}")
            raise

# Singleton instance
try:
    blockchain = BlockchainService()
except Exception as e:
    logger.error(f"Blockchain service setup failed: {e}")
    blockchain = None  # Or raise or handle accordingly
