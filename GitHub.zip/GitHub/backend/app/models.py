from sqlalchemy import Column, Integer, String, DateTime, Text, LargeBinary
from sqlalchemy.sql import func
from app.db import Base

class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True, index=True)
    client_data = Column(Text)
    document_type = Column(String(50))
    generated_text = Column(Text)
    transaction_hash = Column(String(70), nullable=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), nullable=True)
    sender = Column(String(80), nullable=True)
    document_hash = Column(String(80), nullable=True)
    # nft_metadata_url = Column(String(255), nullable=True)  # Add this line

    # REMOVE or COMMENT OUT pdf_file line if present!
