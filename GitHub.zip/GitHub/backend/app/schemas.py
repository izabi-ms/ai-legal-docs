from pydantic import BaseModel
from typing import Optional

class DocumentRequest(BaseModel):
    client_data: str
    document_type: str
    # party_a and party_b are removed

class DocumentResponse(BaseModel):
    document_id: int
    generated_text: str

class NotarizeRequest(BaseModel):
    document_id: int

class NotarizeResponse(BaseModel):
    transaction_hash: str
    document_hash: str

class StatusResponse(BaseModel):
    transaction_hash: Optional[str]
    timestamp: Optional[str]
    document_hash: str

class SaveTxRequest(BaseModel):
    document_id: int
    transaction_hash: str
    document_hash: str
    sender: str

class HistoryDocumentResponse(BaseModel):
    document_id: int
    client_data: str
    document_type: str
    generated_text: str
    transaction_hash: Optional[str]
    document_hash: Optional[str]
    sender: Optional[str]
    timestamp: Optional[str]
    has_pdf: Optional[bool] = False  # NEW
