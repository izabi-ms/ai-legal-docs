"""
encryption.py
-----------------

Utility module providing symmetric encryption and decryption for PDF files using
the `cryptography` library's Fernet implementation. Fernet provides AES-128
encryption in CBC mode with HMAC authentication to ensure both
confidentiality and integrity of the encrypted payload. If the encrypted
contents are modified or corrupted, decryption will fail with an
``InvalidToken`` exception.

The module persists a single secret key on first use by writing it to
``encryption_key.key`` in the application directory. This ensures that all
encrypt/decrypt operations across server restarts use the same key. If an
environment variable named ``ENCRYPTION_KEY`` is provided, it will be used
instead of generating a new key.

Usage:

>>> from app.encryption import encrypt_file, decrypt_file, verify_bytes
>>> encrypt_file("/path/to/input.pdf", "/path/to/output.pdf.enc")
>>> decrypt_file("/path/to/output.pdf.enc", "/path/to/decrypted.pdf")
>>> is_valid = verify_bytes(open("/path/to/output.pdf.enc", "rb").read())

Errors raised during decryption are caught by the helper functions so that
caller code can respond appropriately (e.g. treat a verification failure as
tampering).
"""

import os
from typing import Optional

from cryptography.fernet import Fernet, InvalidToken


def _load_or_create_key() -> bytes:
    """Load the encryption key from file or environment, generating it if needed.

    Returns the raw key bytes. The key is loaded from the ``ENCRYPTION_KEY``
    environment variable if present. Otherwise the module attempts to read
    ``encryption_key.key`` from disk. If the file does not exist, a new key
    is generated using ``Fernet.generate_key()`` and written to disk for
    future use.
    """
    # Priority: environment variable
    env_key = os.getenv("ENCRYPTION_KEY")
    if env_key:
        # If provided, assume it is base64‐encoded as required by Fernet
        return env_key.encode()

    key_path = os.path.join(os.path.dirname(__file__), "encryption_key.key")
    if os.path.exists(key_path):
        with open(key_path, "rb") as key_file:
            return key_file.read().strip()

    # Generate a new key and persist it
    key = Fernet.generate_key()
    with open(key_path, "wb") as key_file:
        key_file.write(key)
    return key


_FERNET: Optional[Fernet] = None


def _get_fernet() -> Fernet:
    """Lazy initialisation of the Fernet object using the loaded key."""
    global _FERNET
    if _FERNET is None:
        key = _load_or_create_key()
        _FERNET = Fernet(key)
    return _FERNET


def encrypt_bytes(data: bytes) -> bytes:
    """Encrypt raw bytes and return the encrypted token.

    Args:
        data: Plaintext bytes to encrypt.

    Returns:
        The encrypted byte sequence (token). This token includes an
        authentication tag; any modification to the token will cause
        decryption to fail.
    """
    f = _get_fernet()
    return f.encrypt(data)


def decrypt_bytes(token: bytes) -> bytes:
    """Decrypt a Fernet token back into plaintext bytes.

    Args:
        token: Encrypted token produced by ``encrypt_bytes``.

    Returns:
        The decrypted plaintext bytes.

    Raises:
        InvalidToken: if the token is invalid, expired or tampered with.
    """
    f = _get_fernet()
    return f.decrypt(token)


def encrypt_file(input_path: str, output_path: str) -> None:
    """Encrypt a file on disk and write the encrypted content to ``output_path``.

    Args:
        input_path: Path to the plaintext file to encrypt.
        output_path: Path where the encrypted file should be written.

    Raises:
        FileNotFoundError: if ``input_path`` does not exist.
    """
    if not os.path.isfile(input_path):
        raise FileNotFoundError(f"Input file not found: {input_path}")
    with open(input_path, "rb") as infile:
        plaintext = infile.read()
    token = encrypt_bytes(plaintext)
    # Ensure target directory exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "wb") as outfile:
        outfile.write(token)


def decrypt_file(input_path: str, output_path: str) -> None:
    """Decrypt an encrypted file and write the plaintext to ``output_path``.

    Args:
        input_path: Path to the encrypted file.
        output_path: Path where the decrypted plaintext should be written.

    Raises:
        FileNotFoundError: if ``input_path`` does not exist.
        InvalidToken: if the encrypted file is invalid or has been tampered with.
    """
    if not os.path.isfile(input_path):
        raise FileNotFoundError(f"Input file not found: {input_path}")
    with open(input_path, "rb") as infile:
        token = infile.read()
    plaintext = decrypt_bytes(token)  # May raise InvalidToken
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "wb") as outfile:
        outfile.write(plaintext)


def verify_bytes(token: bytes) -> bool:
    """Verify that encrypted bytes have not been tampered with.

    Attempts to decrypt the token using the current secret key. If the token
    decrypts successfully, the data is considered authentic. If an
    ``InvalidToken`` exception is raised, the token is considered invalid or
    tampered with and the function returns False.

    Args:
        token: Encrypted byte sequence to verify.

    Returns:
        True if decryption succeeds, False otherwise.
    """
    try:
        decrypt_bytes(token)
        return True
    except InvalidToken:
        return False
    
    
    
