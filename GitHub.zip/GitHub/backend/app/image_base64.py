import base64

def image_to_base64(file_path):
    with open(file_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')

# Usage example
base64_string = image_to_base64("C:\\Users\\new\\Desktop\\All New\\New_New\\backend\\cpy.png")
print(f"data:image/png;base64,{base64_string}")