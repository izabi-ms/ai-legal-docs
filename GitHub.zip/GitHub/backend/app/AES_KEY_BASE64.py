import os
import base64

# Generate a 256-bit (32-byte) AES key
aes_key = os.urandom(32)

# Convert the AES key to base64
aes_key_base64 = base64.b64encode(aes_key).decode()

# Print the base64 encoded AES key
print(aes_key_base64)
