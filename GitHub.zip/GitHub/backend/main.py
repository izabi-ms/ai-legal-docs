import os
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, List

from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse, StreamingResponse
from sqlalchemy.orm import Session

from app import models, schemas, db, blockchain, ollama_service
from app.rag_service import RAGService
from app.utils import sanitize_input

# -- PyPDF2 for watermarking --
from PyPDF2 import PdfReader, PdfWriter

# --- For advanced PDF generation (letterhead style) ---
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch

# --- For gif watermark ---
from app.pdf_gif_watermark import add_gif_watermark, verify_gif_watermark
from app.nft_gif_watermark import create_nft_metadata, fetch_random_gif, upload_to_ipfs

app = FastAPI()

origins = [
    "http://localhost:5173",
    "http://localhost:3000",
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

models.Base.metadata.create_all(bind=db.engine)
rag = RAGService()
ollama = ollama_service.OllamaService()

@app.post("/generate/stream")
async def stream_generate(request: Request):
    data = await request.json()
    template_id = data.get("template_id")
    field_values = data.get("fields")
    with open("app/templates.json", "r", encoding="utf-8") as f:
        templates = json.load(f)
    template = next((t for t in templates if t["id"] == template_id), None)
    if not template:
        raise HTTPException(status_code=400, detail="Invalid template_id")
    required_ids = [f['id'] for f in template['fields']]
    if not all(fid in field_values and field_values[fid] for fid in required_ids):
        raise HTTPException(status_code=422, detail="Missing required fields")
    ai_prompt = template['ai_prompt'].format(**field_values)
    def generate():
        for chunk in ollama.generate_stream(ai_prompt):
            yield chunk
    return StreamingResponse(generate(), media_type="text/plain")

def generate_pdf(document_text, doc_id, file_path):
    doc = SimpleDocTemplate(
        file_path,
        pagesize=letter,
        rightMargin=40,
        leftMargin=40,
        topMargin=36,
        bottomMargin=36
    )
    styles = getSampleStyleSheet()
    # Custom styles
    heading_style = ParagraphStyle(
        'HeadingStyle',
        parent=styles['Heading2'],
        fontSize=12,
        leading=16,
        spaceAfter=8,
        spaceBefore=14,
        textColor=colors.black,
    )
    body_style = ParagraphStyle(
        'BodyStyle',
        parent=styles['Normal'],
        fontSize=11,
        leading=16,
        spaceAfter=10,
        spaceBefore=2,
        textColor=colors.black,
    )
    meta_style = ParagraphStyle(
        'MetaStyle',
        parent=styles['Normal'],
        fontSize=10,
        leading=12,
        spaceAfter=3,
        textColor=colors.black,
    )
    right_style = ParagraphStyle(
        'RightStyle',
        parent=styles['Normal'],
        fontSize=10,
        leading=12,
        alignment=2,
        textColor=colors.HexColor("#203778"),
        spaceAfter=0,
        spaceBefore=0,
    )
    right_gray = ParagraphStyle(
        'RightGray',
        parent=styles['Normal'],
        fontSize=8.5,
        leading=10,
        alignment=2,
        textColor=colors.black,
        spaceAfter=0,
        spaceBefore=0,
    )
    italic_style = ParagraphStyle(
        'ItalicStyle',
        parent=styles['Italic'],
        fontSize=9,
        leading=12,
        alignment=2,
        textColor=colors.black,
    )
    story = []
    # Header table with duck image and address block (can be blank or a placeholder)
    duck_path = "C:\\Users\\new\\Desktop\\All New\\New_New\\duck_1.png"
    if os.path.isfile(duck_path):
        duck_img = Image(duck_path, width=40, height=40)
    else:
        duck_img = Spacer(1, 40)
    right_block = [
        Paragraph("<b>LexChain</b>", right_style),
        Paragraph("Address", right_gray),
        Paragraph("Post", right_gray),
        Paragraph("www.lexchain.com", right_gray),
        Spacer(1, 1),
        Paragraph("Name", right_gray),
        Paragraph("<i>Attorney at Law</i>", italic_style),
        Paragraph("Email: draft.support@lexchain.com", right_gray),
        Paragraph("Phone: 501-555-7748", right_gray)
    ]
    table = Table([[duck_img, right_block]], colWidths=[50, 410])
    table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('TOPPADDING', (0, 0), (-1, -1), 0),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
    ]))
    story.append(table)
    story.append(Spacer(1, 14))
    # Date (centered)
    import datetime as dt
    today = dt.date.today().strftime("%B %d, %Y")
    story.append(Paragraph(today, ParagraphStyle('center', alignment=1, fontSize=11, spaceAfter=12)))
    story.append(Spacer(1, 6))
    # Document ID and type
    story.append(Paragraph(f"Document ID: {doc_id}", meta_style))
    story.append(Paragraph("AI Generated Legal Document", meta_style))
    story.append(Spacer(1, 8))
    # Document body (letterhead style: paragraphs per blank line)
    paragraphs = document_text.split('\n\n')
    for para in paragraphs:
        para = para.strip()
        if not para:
            story.append(Spacer(1, 6))
            continue
        # Heading detection
        if (para.isupper() and len(para) < 80) or para.startswith("**"):
            para = para.replace("**", "")
            story.append(Paragraph(para, heading_style))
        else:
            story.append(Paragraph(para, body_style))
    # Disclaimer and blockchain info
    story.append(Spacer(1, 16))
    story.append(Paragraph(
        "<font color='#800000'><b>Disclaimer:</b> This document was generated by AI and notarized on blockchain. For legal validity, consult a professional.</font>",
        meta_style
    ))
    story.append(Spacer(1, 8))
    doc.build(story)

@app.post("/notarize", response_model=schemas.NotarizeResponse)
def notarize_document(request: schemas.NotarizeRequest, session: Session = Depends(db.get_db)):
    document = session.query(models.Document).filter(models.Document.id == request.document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    doc_hash = blockchain.hash_document(document.generated_text)
    tx_hash = blockchain.notarize_hash_on_chain(doc_hash)
    document.transaction_hash = tx_hash
    document.document_hash = doc_hash
    document.timestamp = datetime.utcnow()
    session.commit()
    os.makedirs("pdfs", exist_ok=True)
    pdf_path = f"pdfs/LegalDocument_{document.id}.pdf"
    generate_pdf(document.generated_text, document.id, pdf_path)
    return schemas.NotarizeResponse(transaction_hash=tx_hash, document_hash=doc_hash)

@app.get("/status/{document_id}", response_model=schemas.StatusResponse)
def document_status(document_id: int, session: Session = Depends(db.get_db)):
    document = session.query(models.Document).filter(models.Document.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    return schemas.StatusResponse(
        transaction_hash=document.transaction_hash,
        timestamp=document.timestamp,
        document_hash=blockchain.hash_document(document.generated_text)
    )

@app.post("/saveTx")
def save_transaction(data: schemas.SaveTxRequest, session: Session = Depends(db.get_db)):
    try:
        document = session.query(models.Document).filter(models.Document.id == data.document_id).first()
        if not document:
            return JSONResponse(status_code=404, content={"error": "Document not found"})
        document.transaction_hash = data.transaction_hash
        document.sender = data.sender
        document.document_hash = data.document_hash
        document.timestamp = datetime.utcnow()
        session.commit()
        os.makedirs("pdfs", exist_ok=True)
        pdf_path = f"pdfs/LegalDocument_{document.id}.pdf"
        generate_pdf(document.generated_text, document.id, pdf_path)
        return {"status": "success"}
    except Exception as e:
        session.rollback()
        return JSONResponse(status_code=500, content={"error": str(e)})

@app.get("/history", response_model=List[schemas.HistoryDocumentResponse])
def get_history(sender: Optional[str] = None, session: Session = Depends(db.get_db)):
    query = session.query(models.Document)
    if sender:
        query = query.filter(models.Document.sender == sender)
    docs = query.order_by(models.Document.timestamp.desc()).all()
    return [
        {
            "document_id": d.id,
            "client_data": d.client_data,
            "document_type": d.document_type,
            "generated_text": d.generated_text,
            "transaction_hash": d.transaction_hash,
            "document_hash": d.document_hash,
            "sender": d.sender,
            "timestamp": str(d.timestamp) if d.timestamp else None,
            "has_pdf": os.path.isfile(f"pdfs/LegalDocument_{d.id}.pdf"),
            "has_watermark": has_watermark(f"pdfs/LegalDocument_{d.id}.pdf", d.id, d.document_hash) if d.document_hash else False,
            "nft_metadata_url": getattr(d, 'nft_metadata_url', None),
            "gif_url": getattr(d, 'gif_url', None), # Add this to keep track of GIF watermark
        }
        for d in docs
    ]

@app.post("/savePdf")
async def save_pdf(document_id: int, pdf: UploadFile = File(...), session: Session = Depends(db.get_db)):
    document = session.query(models.Document).filter(models.Document.id == document_id).first()
    if not document:
        return JSONResponse(status_code=404, content={"error": "Document not found"})
    os.makedirs("pdfs", exist_ok=True)
    file_path = f"pdfs/LegalDocument_{document_id}.pdf"
    with open(file_path, "wb") as f:
        content = await pdf.read()
        f.write(content)
    return {"status": "pdf saved"}

@app.get("/pdf/{document_id}")
def get_pdf(document_id: int):
    file_path = f"pdfs/LegalDocument_{document_id}.pdf"
    if os.path.isfile(file_path):
        return FileResponse(file_path, media_type="application/pdf", filename=f"LegalDocument_{document_id}.pdf")
    raise HTTPException(status_code=404, detail="PDF not found")

@app.get("/templates")
def get_templates():
    with open("app/templates.json", "r", encoding="utf-8") as f:
        templates = json.load(f)
    return templates

@app.post("/document")
async def save_generated_document(
    request: Request,
    session: Session = Depends(db.get_db)
):
    try:
        data = await request.json()
        client_data = data.get("client_data")
        document_type = data.get("document_type")
        generated_text = data.get("generated_text")
        if not all([client_data, document_type, generated_text]):
            return JSONResponse(status_code=422, content={
                "error": "Missing required fields",
                "details": {
                    "client_data": client_data,
                    "document_type": document_type,
                    "generated_text": generated_text
                }
            })
        doc = models.Document(
            client_data=client_data,
            document_type=document_type,
            generated_text=generated_text,
        )
        session.add(doc)
        session.commit()
        session.refresh(doc)
        return {"document_id": doc.id}
    except Exception as e:
        session.rollback()
        return JSONResponse(status_code=500, content={"error": str(e)})

@app.delete("/document/{document_id}")
def delete_document(document_id: int, session: Session = Depends(db.get_db)):
    doc = session.query(models.Document).filter_by(id=document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    pdf_path = f"pdfs/LegalDocument_{document_id}.pdf"
    if os.path.isfile(pdf_path):
        os.remove(pdf_path)
    session.delete(doc)
    session.commit()
    return {"status": "deleted"}

def watermark_text(document_id: int, document_hash: str) -> str:
    return f"LexChainID:{document_id};Hash:{document_hash}"

def add_pdf_metadata_watermark(input_path: str, output_path: str, watermark: str):
    reader = PdfReader(input_path)
    writer = PdfWriter()
    for page in reader.pages:
        writer.add_page(page)
    metadata = dict(reader.metadata) if reader.metadata else {}
    metadata["/Watermark"] = watermark
    writer.add_metadata(metadata)
    with open(output_path, "wb") as out_f:
        writer.write(out_f)

def has_watermark(pdf_path: str, document_id: int, document_hash: str) -> bool:
    try:
        reader = PdfReader(pdf_path)
        watermark = reader.metadata.get("/Watermark")
        return watermark == watermark_text(document_id, document_hash)
    except Exception:
        return False

@app.post("/watermark_pdf/{document_id}")
def watermark_pdf(document_id: int, session: Session = Depends(db.get_db)):
    document = session.query(models.Document).filter(models.Document.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    pdf_path = f"pdfs/LegalDocument_{document_id}.pdf"
    output_path = pdf_path  # Overwrite in place
    if not os.path.isfile(pdf_path):
        raise HTTPException(status_code=404, detail="PDF not found")
    try:
        add_pdf_metadata_watermark(
            input_path=pdf_path,
            output_path=output_path,
            watermark=watermark_text(document_id, document.document_hash)
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Could not watermark PDF: {e}")
    return {"status": "watermarked"}

@app.post("/verify_pdf/{document_id}")
async def verify_pdf(document_id: int, file: UploadFile = File(...), session: Session = Depends(db.get_db)):
    document = session.query(models.Document).filter(models.Document.id == document_id).first()
    if not document:
        return {"valid": False, "reason": "Document not found"}
    data = await file.read()
    from io import BytesIO
    try:
        reader = PdfReader(BytesIO(data))
        watermark = reader.metadata.get("/Watermark")
        expected = watermark_text(document_id, document.document_hash)
        return {"valid": watermark == expected}
    except Exception as e:
        return {"valid": False, "reason": str(e)}

# ---- GIF WATERMARK ENDPOINTS ----

@app.post("/gif_watermark_pdf/{document_id}")
def gif_watermark_pdf(document_id: int, session: Session = Depends(db.get_db)):
    document = session.query(models.Document).filter(models.Document.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    pdf_path = f"pdfs/LegalDocument_{document_id}.pdf"
    output_path = pdf_path  # Overwrite
    if not os.path.isfile(pdf_path):
        raise HTTPException(status_code=404, detail="PDF not found")
    try:
        # Fetch random GIF and save locally
        gif_bytes = fetch_random_gif()
        gif_path = f"temp/watermark_{document_id}.gif"
        os.makedirs("temp", exist_ok=True)
        with open(gif_path, "wb") as f:
            f.write(gif_bytes)
        # Upload GIF to IPFS and create metadata
        gif_url = upload_to_ipfs(gif_bytes)
        metadata_url = create_nft_metadata(document.document_hash, gif_url)
        document.nft_metadata_url = metadata_url
        document.gif_url = gif_url
        session.commit()
        # Metadata string to encode
        gif_metadata = f"GIFID:{document_id};Hash:{document.document_hash};Meta:{metadata_url};GifUrl:{gif_url}"
        # Add GIF watermark
        add_gif_watermark(pdf_path, output_path, gif_path, gif_metadata, opacity=0.10, size=(32, 32))
        return {"status": "gif_watermarked", "metadata_url": metadata_url, "gif_url": gif_url}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Could not add GIF watermark: {str(e)}")

@app.post("/verify_gif_pdf/{document_id}")
async def verify_gif_pdf(document_id: int, file: UploadFile = File(...), session: Session = Depends(db.get_db)):
    document = session.query(models.Document).filter(models.Document.id == document_id).first()
    if not document:
        return {"valid": False, "reason": "Document not found"}
    data = await file.read()
    from io import BytesIO
    expected_metadata = f"GIFID:{document_id};Hash:{document.document_hash};Meta:{document.nft_metadata_url};GifUrl:{document.gif_url}"
    try:
        valid = verify_gif_watermark(BytesIO(data), expected_metadata)
        return {"valid": valid}
    except Exception as e:
        return {"valid": False, "reason": str(e)}