import React, { useEffect, useState } from "react";
import axios from "axios";
import HistoryItem from "./HistoryItem";
import { Spinner, Alert, Button, OverlayTrigger, Tooltip } from "react-bootstrap";
import { FiTrash2, FiDownload, FiEye } from "react-icons/fi";

function HistoryList({ wallet, setDocument, setDocId, setShowHistory }) {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    async function fetchHistory() {
      setLoading(true);
      setError("");
      try {
        const res = await axios.get(
          `${process.env.REACT_APP_BACKEND_URL}/history`,
          { params: { sender: wallet } }
        );
        setHistory(Array.isArray(res.data) ? res.data : []);
      } catch {
        setHistory([]);
        setError("Could not fetch history.");
      }
      setLoading(false);
    }
    if (wallet) fetchHistory();
  }, [wallet, success]);

  // Delete a document
  const handleDelete = async (docId) => {
    if (!window.confirm("Are you sure you want to delete this document?")) return;
    setDeletingId(docId);
    try {
      await axios.delete(`${process.env.REACT_APP_BACKEND_URL}/document/${docId}`);
      setHistory(history.filter(doc => doc.document_id !== docId));
      setSuccess("Document deleted.");
      setTimeout(() => setSuccess(""), 1500);
    } catch {
      setError("Failed to delete document.");
      setTimeout(() => setError(""), 1500);
    }
    setDeletingId(null);
  };

  // Download PDF
  const handleDownloadPdf = async (doc) => {
    try {
      const res = await axios.get(
        `${process.env.REACT_APP_BACKEND_URL}/pdf/${doc.document_id}`,
        { responseType: "blob" }
      );
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `LegalDocument_${doc.document_id}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.parentNode.removeChild(link);
    } catch {
      setError("PDF download failed.");
      setTimeout(() => setError(""), 2000);
    }
  };

  if (loading) return <Spinner animation="border" className="mt-3" />;
  if (!history || !history.length) return <Alert variant="info" className="mt-3">No history found.</Alert>;

  return (
    <div style={{ maxWidth: 740, margin: "0 auto" }}>
      <h4 className="mb-3 mt-2">Your Notarized Documents</h4>
      {success && <div className="alert alert-success">{success}</div>}
      {error && <div className="alert alert-danger">{error}</div>}

      <div className="list-group">
        {history.map(item => (
          <div key={item.document_id}
            className="list-group-item d-flex align-items-center justify-content-between flex-wrap"
            style={{ fontSize: 15, padding: "13px 12px", borderRadius: 9, marginBottom: 7, background: "#f8fafd", boxShadow: "0 1px 4px rgba(32,55,120,0.06)" }}
          >
            <div style={{ flex: 1, minWidth: 0, cursor: "pointer" }}
              onClick={() => {
                setDocument(item.generated_text);
                setDocId(item.document_id);
                setShowHistory(false);
              }}
              title="View Document"
            >
              <div className="fw-semibold" style={{ fontSize: 15.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 320 }}>
                {item.document_type || "Untitled"}
              </div>
              <div style={{ fontSize: 13.5, color: "#456", opacity: .86, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 330 }}>
                {item.generated_text.substring(0, 60)}{item.generated_text.length > 60 ? "..." : ""}
              </div>
              <div style={{ fontSize: 12.2, color: "#7a7a8a", marginTop: 2 }}>
                {item.timestamp && new Date(item.timestamp).toLocaleString()}
              </div>
            </div>
            <div className="d-flex align-items-center gap-2 ms-2">
              <OverlayTrigger placement="top" overlay={<Tooltip>View</Tooltip>}>
                <Button
                  size="sm"
                  variant="outline-primary"
                  style={{ borderRadius: 6, fontSize: 15, padding: "3px 8px" }}
                  onClick={() => {
                    setDocument(item.generated_text);
                    setDocId(item.document_id);
                    setShowHistory(false);
                  }}
                  title="View Document"
                >
                  <FiEye />
                </Button>
              </OverlayTrigger>
              {item.has_pdf && (
                <OverlayTrigger placement="top" overlay={<Tooltip>Download PDF</Tooltip>}>
                  <Button
                    size="sm"
                    variant="outline-success"
                    style={{ borderRadius: 6, fontSize: 15, padding: "3px 8px" }}
                    onClick={() => handleDownloadPdf(item)}
                    title="Download PDF"
                  >
                    <FiDownload />
                  </Button>
                </OverlayTrigger>
              )}
              <OverlayTrigger placement="top" overlay={<Tooltip>Delete</Tooltip>}>
                <Button
                  size="sm"
                  variant="outline-danger"
                  style={{ borderRadius: 6, fontSize: 15, padding: "3px 8px" }}
                  onClick={() => handleDelete(item.document_id)}
                  disabled={deletingId === item.document_id}
                  title="Delete Document"
                >
                  {deletingId === item.document_id ? (
                    <Spinner animation="border" size="sm" />
                  ) : (
                    <FiTrash2 />
                  )}
                </Button>
              </OverlayTrigger>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default HistoryList;
