import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Container, Navbar, Nav, ToastContainer, Dropdown } from "react-bootstrap";
import DocumentForm from "./components/DocumentForm";
import DocumentDisplay from "./components/DocumentDisplay";
import BlockchainStatus from "./components/BlockchainStatus";
import ConnectWallet from "./components/ConnectWallet";
import HistoryList from "./history/HistoryList";
import SettingsModal from "./components/SettingsModal";
import TemplatesList from "./components/TamplatesList";
import VerificationPage from "./components/VerificationPage"; // Import the VerificationPage

function App() {
  const [document, setDocument] = useState(null);
  const [docId, setDocId] = useState(null);
  const [status, setStatus] = useState(null);
  const [wallet, setWallet] = useState(null);
  const [showHistory, setShowHistory] = useState(false);
  const [theme, setTheme] = useState("light");
  const [showSettings, setShowSettings] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [page, setPage] = useState("generate"); // Manage current page

  return (
    <div data-theme={theme}>
      <Navbar
        bg={theme === "dark" ? "dark" : "light"}
        variant={theme === "dark" ? "dark" : "light"}
        expand="lg"
        className="silky-navbar"
      >
        <Container>
          <Navbar.Brand className="fw-bold fs-4" style={{ letterSpacing: 1 }}>
            LegalDocs Blockchain
          </Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link active={page === "generate"} onClick={() => setPage("generate")}>
              Generate
            </Nav.Link>
            <Nav.Link active={page === "history"} onClick={() => setPage("history")}>
              History
            </Nav.Link>
            <Dropdown as={Nav.Item}>
              <Dropdown.Toggle as={Nav.Link} active={page === "verify-lexchain" || page === "verify-duck"}>
                Verify
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item onClick={() => setPage("verify-lexchain")}>
                  Verify LexChain PDF
                </Dropdown.Item>
                <Dropdown.Item onClick={() => setPage("verify-duck")}>
                  Verify Duck Watermarked PDF
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
            <Nav.Link onClick={() => setShowSettings(true)}>Settings</Nav.Link>
          </Nav>
          <div className="ms-auto d-flex">
            <ConnectWallet wallet={wallet} setWallet={setWallet} />
          </div>
        </Container>
      </Navbar>

      <Container className="mt-4" style={{ maxWidth: 720 }}>
        {showSettings && (
          <SettingsModal
            show={showSettings}
            onHide={() => setShowSettings(false)}
            theme={theme}
            setTheme={setTheme}
          />
        )}

        {page === "history" && (
          <div className="fadein">
            <HistoryList
              wallet={wallet}
              setDocument={setDocument}
              setDocId={setDocId}
              setShowHistory={setShowHistory}
            />
          </div>
        )}
        {page === "generate" && (
          <>
            <div className="fadein">
              {!selectedTemplate ? (
                <TemplatesList onSelect={setSelectedTemplate} />
              ) : (
                <DocumentForm
                  setDocument={setDocument}
                  setDocId={setDocId}
                  template={selectedTemplate}
                  onBack={() => setSelectedTemplate(null)}
                />
              )}
              {status && <BlockchainStatus status={status} />}
            </div>
            <DocumentDisplay
              document={document}
              docId={docId}
              setStatus={setStatus}
              wallet={wallet}
              status={status}
              setDocument={setDocument}
              setDocId={setDocId}
            />
          </>
        )}
        {page === "verify-lexchain" && <VerificationPage type="lexchain" />}
        {page === "verify-duck" && <VerificationPage type="duck" />}

        <ToastContainer position="bottom-end" />
      </Container>
    </div>
  );
}

export default App;