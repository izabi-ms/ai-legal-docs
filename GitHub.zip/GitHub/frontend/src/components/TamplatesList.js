import React, { useEffect, useState } from "react";
import axios from "axios";

function TemplatesList({ onSelect }) {
  const [templates, setTemplates] = useState([]);

  useEffect(() => {
    axios.get(`${process.env.REACT_APP_BACKEND_URL}/templates`)
      .then(res => setTemplates(res.data))
      .catch(() => setTemplates([]));
  }, []);

  return (
    <div className="row">
      {templates.map(template => (
        <div key={template.id} className="col-md-6 col-lg-4 mb-4">
          <div className="card silky-card h-100">
            <div className="card-body">
              <h5 className="card-title">{template.name}</h5>
              <p className="card-text">{template.description}</p>
              <ul style={{ fontSize: 14 }}>
                <li><b>Parties:</b> {template.parties.join(", ")}</li>
                <li><b>Use Case:</b> {template.use_case}</li>
                <li><b>Fields:</b> {template.fields.join(", ")}</li>
              </ul>
              <div className="mt-2 mb-2" style={{ fontSize: 13, color: "#888" }}>
                <b>Sample Preview:</b>
                <div style={{
                  background: "#f8f9fa",
                  borderRadius: 10,
                  padding: "0.7em",
                  marginTop: 4,
                  fontFamily: "monospace"
                }}>
                  {template.sample_excerpt}
                </div>
              </div>
              <button
                className="btn silky-btn silky-btn-primary mt-2"
                onClick={() => onSelect(template)}
              >
                Select
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default TemplatesList;
