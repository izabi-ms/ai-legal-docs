import React, { useState, useEffect } from "react";
import { ethers } from "ethers";
import axios from "axios";
import contractABI from "../abi/contract_abi.json";
import Button from "react-bootstrap/Button";

// Place your base64-encoded duck logo image here (PNG recommended)
const duckLogoBase64 = ""; // <-- Put your duck image base64 here

function DocumentDisplay({ document, docId, setStatus, wallet, status, setDocument, setDocId }) {
  const [notarizing, setNotarizing] = useState(false);
  const [notarizeError, setNotarizeError] = useState("");
  const [notarizeSuccess, setNotarizeSuccess] = useState(false);

  const [historyDocs, setHistoryDocs] = useState([]);
  const [selectedDocId, setSelectedDocId] = useState("");
  const [selectedDoc, setSelectedDoc] = useState("");

  const [isEditing, setIsEditing] = useState(false);
  const [editedText, setEditedText] = useState("");

  const [saveError, setSaveError] = useState("");
  const [saveSuccess, setSaveSuccess] = useState(false);

  const [watermarking, setWatermarking] = useState(false);
  const [watermarkSuccess, setWatermarkSuccess] = useState(false);
  const [watermarkError, setWatermarkError] = useState("");
  const [pdfStatus, setPdfStatus] = useState("");
  const [verifyResult, setVerifyResult] = useState("");
  const [nftMetadataUrl, setNftMetadataUrl] = useState("");
  const [gifUrl, setGifUrl] = useState(""); // For GIF watermark

  useEffect(() => {
    async function checkWatermark() {
      const id = selectedDocId || docId;
      if (!id) return;
      try {
        const res = await axios.get(
          `${process.env.REACT_APP_BACKEND_URL}/pdf/${id}`,
          { responseType: "arraybuffer" }
        );
        if (res.status === 200) setPdfStatus("PDF is ready for watermarking or download.");
      } catch {
        setPdfStatus("");
      }
    }
    checkWatermark();
  }, [docId, selectedDocId, status, watermarkSuccess]);

  useEffect(() => {
    async function fetchHistory() {
      if (!wallet) return;
      try {
        const res = await axios.get(
          `${process.env.REACT_APP_BACKEND_URL}/history`,
          { params: { sender: wallet } }
        );
        setHistoryDocs(Array.isArray(res.data) ? res.data : []);
      } catch (err) {
        setHistoryDocs([]);
      }
    }
    fetchHistory();
  }, [wallet]);

  useEffect(() => {
    if (!selectedDocId || selectedDocId === "-") {
      setSelectedDoc("");
      setIsEditing(true);
      setEditedText(document || "");
      return;
    }
    const docObj = historyDocs.find(d => d.document_id === selectedDocId);
    setSelectedDoc(docObj ? docObj.generated_text : "");
    setIsEditing(false);
    setNftMetadataUrl(docObj?.nft_metadata_url || "");
    setGifUrl(docObj?.gif_url || "");
  }, [selectedDocId, historyDocs, document]);

  useEffect(() => {
    if (document && !docId && !selectedDocId) {
      setIsEditing(true);
      setEditedText(document);
    }
  }, [document, docId, selectedDocId]);

  const handleSaveEdited = async () => {
    setSaveError("");
    setSaveSuccess(false);
    if (!editedText.trim()) {
      setSaveError("Document cannot be empty.");
      return;
    }
    try {
      const saveRes = await axios.post(
        `${process.env.REACT_APP_BACKEND_URL}/document`,
        {
          client_data: "Edited document",
          document_type: "Custom",
          generated_text: editedText,
        }
      );
      setDocId(saveRes.data.document_id);
      setDocument(editedText);
      setIsEditing(false);
      setSaveSuccess(true);
    } catch (err) {
      setSaveError("Saving failed. Please try again.");
    }
  };

  const handleNotarize = async () => {
    setNotarizing(true);
    setNotarizeError("");
    setNotarizeSuccess(false);

    if (!window.ethereum || !wallet) {
      setNotarizeError("Connect your MetaMask wallet first.");
      setNotarizing(false);
      return;
    }
    const currentDocId = selectedDocId || docId;
    const currentDocument = isEditing ? editedText : (selectedDoc || document);
    if (!currentDocId) {
      setNotarizeError("Error: No document ID. Please generate and save the document first.");
      setNotarizing(false);
      return;
    }
    try {
      const provider = new ethers.BrowserProvider(window.ethereum);
      await provider.send("eth_requestAccounts", []);
      const signer = await provider.getSigner();
      const network = await provider.getNetwork();
      if (network.chainId !== 11155111) {
        try {
          await window.ethereum.request({
            method: "wallet_switchEthereumChain",
            params: [{ chainId: "0xaa36a7" }],
          });
        } catch {
          setNotarizeError("Please switch to the Sepolia network in MetaMask.");
          setNotarizing(false);
          return;
        }
      }
      const contract = new ethers.Contract(
        process.env.REACT_APP_CONTRACT_ADDRESS,
        contractABI,
        signer
      );
      const hash = ethers.keccak256(ethers.toUtf8Bytes(currentDocument));
      const tx = await contract.notarizeDocument(hash);
      await tx.wait();

      setStatus({ txHash: tx.hash, docHash: hash, sender: wallet });

      await axios.post(`${process.env.REACT_APP_BACKEND_URL}/saveTx`, {
        document_id: currentDocId,
        transaction_hash: tx.hash,
        document_hash: hash,
        sender: wallet,
      });

      setPdfStatus("PDF is ready for watermarking.");
      setNotarizeSuccess(true);
    } catch (err) {
      setNotarizeError("MetaMask transaction failed: " + (err?.message || JSON.stringify(err)));
    }
    setNotarizing(false);
  };

  const handleWatermark = async () => {
    setWatermarking(true);
    setWatermarkError("");
    setWatermarkSuccess(false);
    const currentDocId = selectedDocId || docId;
    try {
      await axios.post(`${process.env.REACT_APP_BACKEND_URL}/watermark_pdf/${currentDocId}`);
      setWatermarkSuccess(true);
      setPdfStatus("PDF is LexChain watermarked. You can add GIF watermark or download.");
    } catch (err) {
      setWatermarkError("Watermarking failed: " + (err?.response?.data?.detail || err.message));
    }
    setWatermarking(false);
  };

  // Handler for GIF Watermark (replace Duck watermark)
  const handleGIFWatermark = async () => {
    const currentDocId = selectedDocId || docId;
    if (!currentDocId) {
      alert("No document selected for GIF watermarking.");
      return;
    }
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_BACKEND_URL}/gif_watermark_pdf/${currentDocId}`
      );
      setNftMetadataUrl(response.data.metadata_url);
      setGifUrl(response.data.gif_url);
      alert(
        "GIF Watermark Added!\nMetadata URL: " +
          response.data.metadata_url +
          "\nGIF URL: " +
          response.data.gif_url
      );
    } catch (err) {
      console.error(err);
      alert("Error adding GIF watermark.");
    }
  };

  // ----- Letterhead PDF Download -----
  const handleDownloadPDF = async () => {
    const docToExport = isEditing ? editedText : selectedDoc || document;
    const docPdf = new window.jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4"
    });

    // Margins
    const leftMargin = 20;
    const rightMargin = 20;
    let y = 18;

    // Duck logo at top left (optional, invisible if blank)
    if (duckLogoBase64 && window.jsPDF) {
      docPdf.addImage(duckLogoBase64, "PNG", leftMargin, y, 22, 22);
    }

    // Law firm/brand info at top right
    docPdf.setFont("helvetica", "bold");
    docPdf.setFontSize(14);
    docPdf.setTextColor(32, 55, 120);
    docPdf.text("LEGALDOCS DRAFT", 210 - rightMargin, y + 2, { align: "right" });
    docPdf.setFont("helvetica", "normal");
    docPdf.setFontSize(10);
    docPdf.setTextColor(40, 40, 40);
    docPdf.text("123 Fourth Avenue", 210 - rightMargin, y + 9, { align: "right" });
    docPdf.text("Cityville, New State 98765", 210 - rightMargin, y + 14, { align: "right" });
    docPdf.text("www.legaldocs.com", 210 - rightMargin, y + 19, { align: "right" });

    docPdf.text("Cory Bates-Rogers", 210 - rightMargin, y + 25, { align: "right" });
    docPdf.setFont("helvetica", "italic");
    docPdf.setFontSize(9);
    docPdf.text("Attorney at Law", 210 - rightMargin, y + 30, { align: "right" });
    docPdf.setFont("helvetica", "normal");
    docPdf.setFontSize(9);
    docPdf.text("Email: draft.support@legaldocs.com", 210 - rightMargin, y + 34, { align: "right" });
    docPdf.text("Phone: 501-555-7748", 210 - rightMargin, y + 38, { align: "right" });

    y += 45;

    // Date (centered)
    docPdf.setFont("helvetica", "normal");
    docPdf.setFontSize(11);
    docPdf.setTextColor(0, 0, 0);
    const today = new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
    docPdf.text(today, 105, y, { align: "center" });

    y += 10;

    // Document ID and type
    docPdf.setFontSize(10);
    docPdf.text(`Document ID: ${selectedDocId || docId || "Draft"}`, leftMargin, y);
    docPdf.setFont("helvetica", "bold");
    docPdf.text("AI Generated Legal Document", leftMargin, y + 6);
    y += 14;

    // Split paragraphs for legal letter style
    docPdf.setFont("helvetica", "normal");
    docPdf.setFontSize(11);
    const paragraphs = docToExport.split(/\n\s*\n/);

    paragraphs.forEach((para, idx) => {
      const lines = docPdf.splitTextToSize(para.trim(), 210 - leftMargin - rightMargin);
      lines.forEach((line) => {
        docPdf.text(line, leftMargin, y);
        y += 6;
        if (y > 280) {
          docPdf.addPage();
          y = 20;
        }
      });
      y += 3;
    });

    y += 6;

    // Disclaimer and blockchain info
    docPdf.setFontSize(9);
    docPdf.setTextColor(120, 0, 0);
    docPdf.text(
      "Disclaimer: This document was generated by AI and notarized on blockchain. For legal validity, consult a professional.",
      leftMargin,
      y
    );
    y += 8;

    docPdf.setFontSize(8);
    docPdf.setTextColor(100, 100, 100);
    if (status && status.txHash && status.docHash) {
      docPdf.text(
        `Transaction Hash: https://sepolia.etherscan.io/tx/${status.txHash}`,
        leftMargin,
        y
      );
      y += 5;
      docPdf.text(`Document Hash: ${status.docHash}`, leftMargin, y);
      y += 5;
      docPdf.text(`Notary: ${status.sender || ""}`, leftMargin, y);
      y += 6;
    }
    docPdf.text("Generated by Lexchain | Notarize for authenticity", leftMargin, 290);

    // --- GIF watermark in margin, if available ---
    if (gifUrl && window.jsPDF) {
      // jsPDF does NOT support GIF directly, only PNG/JPEG: use a static link or convert GIF to PNG in backend.
      // Optionally, you can fetch the GIF as PNG from backend and use its base64.
      // Here, just link the GIF visually (low opacity, small size, margin)
      if (docPdf.setOpacity) docPdf.setOpacity(0.10); // Set low opacity
      // Example: place GIF at bottom right margin, 16x16mm
      docPdf.addImage(gifUrl, "PNG", 190, 282, 16, 16); // For PNG. If using GIF, convert before usage.
      if (docPdf.setOpacity) docPdf.setOpacity(1.0); // Reset
    }

    docPdf.save(`LegalDocument_${selectedDocId || docId || "draft"}.pdf`);

    // Optionally, upload to backend as before
    const uploadId = selectedDocId || docId;
    if (uploadId) {
      const pdfBlob = docPdf.output("blob");
      const formData = new FormData();
      formData.append("pdf", pdfBlob, `LegalDocument_${uploadId}.pdf`);
      try {
        await axios.post(
          `${process.env.REACT_APP_BACKEND_URL}/savePdf?document_id=${uploadId}`,
          formData,
          { headers: { "Content-Type": "multipart/form-data" } }
        );
      } catch (err) {
        console.error("Failed to save PDF to backend:", err);
      }
    }
  };

  const downloadLinkId = selectedDocId || docId;
  const displayText = isEditing ? editedText : (selectedDoc || document);

  return (
    <div className="card mt-4 silky-card shadow fadein">
      <div className="card-body">
        <div className="mb-2">
          <label className="fw-bold">Show previous documents:</label>
          <select
            value={selectedDocId}
            onChange={e => setSelectedDocId(e.target.value)}
            className="form-select"
            style={{ maxWidth: 300, display: "inline-block", marginLeft: 12, marginBottom: 8 }}
          >
            <option value="-">Current (Unsaved or New)</option>
            {historyDocs.map(doc => (
              <option key={doc.document_id} value={doc.document_id}>
                {doc.document_type || "Untitled"} - {doc.document_id}
              </option>
            ))}
          </select>
          <span className="ms-2 text-muted" style={{ fontSize: 13 }}>
            Select to view your previously generated documents.
          </span>
        </div>
        {isEditing ? (
          <div>
            <label className="fw-bold mb-1">Edit Document Before Save, PDF, or Notarization:</label>
            <textarea
              value={editedText}
              onChange={e => setEditedText(e.target.value)}
              placeholder="Edit your document here before saving/notarizing..."
              style={{
                width: "100%",
                minHeight: 320,
                fontSize: 15.5,
                background: "#fff8e1",
                padding: "1.2em",
                whiteSpace: "pre-wrap",
                borderRadius: "14px",
                border: "2px solid #ffd54f"
              }}
            />
            <div className="d-flex gap-2 mt-2">
              <button
                className="btn silky-btn silky-btn-primary"
                onClick={handleSaveEdited}
                disabled={!editedText.trim()}
              >
                Save Document
              </button>
              <button
                className="btn silky-btn silky-btn-outline"
                onClick={() => setIsEditing(false)}
              >
                Cancel
              </button>
            </div>
            {saveError && <div className="text-danger mt-2">{saveError}</div>}
            {saveSuccess && <div className="text-success mt-2">Document saved!</div>}
          </div>
        ) : (
          <textarea
            value={displayText}
            readOnly
            placeholder="Your generated document will appear here..."
            style={{
              width: "100%",
              minHeight: 320,
              fontSize: 15.5,
              background: "#f8f9fa",
              padding: "1.2em",
              whiteSpace: "pre-wrap",
              borderRadius: "14px",
            }}
          />
        )}
        <div className="d-flex gap-3 mt-3 flex-wrap">
          <button
            className="btn silky-btn silky-btn-primary"
            onClick={handleNotarize}
            disabled={notarizing || !wallet || status?.txHash || isEditing}
            title={status?.txHash ? "Already notarized" : ""}
          >
            {notarizing ? (
              <span>
                <span className="spinner-border spinner-border-sm me-2" role="status" /> Notarizing...
              </span>
            ) : status?.txHash ? "Already Notarized" : "Notarize on Blockchain"}
          </button>
          <button
            className="btn silky-btn silky-btn-outline"
            onClick={handleWatermark}
            disabled={watermarking || !status?.txHash}
          >
            {watermarking ? "Watermarking..." : "Add LexChain Watermark"}
          </button>
          <Button
            variant="secondary"
            onClick={handleGIFWatermark}
            disabled={!status?.txHash}
          >
            Add GIF Watermark
          </Button>
          <a
            className="btn silky-btn silky-btn-success"
            href={
              downloadLinkId
                ? `${process.env.REACT_APP_BACKEND_URL}/pdf/${downloadLinkId}`
                : "#"
            }
            target="_blank"
            rel="noopener noreferrer"
            style={{
              pointerEvents: status?.txHash ? "auto" : "none",
              opacity: status?.txHash ? 1 : 0.5,
            }}
          >
            Download Official PDF
          </a>
          <button
            className="btn silky-btn silky-btn-outline"
            onClick={handleDownloadPDF}
          >
            Download Letterhead PDF
          </button>
          {!isEditing && (
            <button
              className="btn silky-btn silky-btn-outline"
              onClick={() => {
                setIsEditing(true);
                setEditedText(displayText);
              }}
            >
              Edit Document
            </button>
          )}
        </div>
        {nftMetadataUrl && (
          <div className="alert alert-info mt-2">
            NFT Metadata:{" "}
            <a href={nftMetadataUrl} target="_blank" rel="noopener noreferrer">
              {nftMetadataUrl}
            </a>
          </div>
        )}
        {gifUrl && (
          <div className="alert alert-info mt-2">
            GIF Watermark:{" "}
            <a href={gifUrl} target="_blank" rel="noopener noreferrer">
              {gifUrl}
            </a>
          </div>
        )}
        {!wallet && (
          <div className="text-danger mt-2">
            Connect your MetaMask wallet to notarize.
          </div>
        )}
        {pdfStatus && (
          <div className="alert alert-info mt-3">{pdfStatus}</div>
        )}
        {watermarkError && (
          <div className="alert alert-danger mt-3">{watermarkError}</div>
        )}
        {notarizeError && (
          <div className="alert alert-danger mt-3">{notarizeError}</div>
        )}
        {notarizeSuccess && (
          <div className="alert alert-success mt-3">
            Notarization successful! <br />
            <a
              href={`https://sepolia.etherscan.io/tx/${status?.txHash}`}
              target="_blank"
              rel="noopener noreferrer"
            >View transaction on Etherscan</a>
          </div>
        )}
        {status && status.txHash && (
          <div className="alert alert-info mt-3">
            <b>Notarized:</b>
            <div>Transaction Hash: <code>{status.txHash}</code></div>
            <div>Document Hash: <code>{status.docHash}</code></div>
            <div>Sender: <code>{status.sender}</code></div>
            <div>
              <a
                href={`https://sepolia.etherscan.io/tx/${status.txHash}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                View on Etherscan
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default DocumentDisplay;