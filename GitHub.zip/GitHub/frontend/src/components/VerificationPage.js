import React, { useState } from "react";
import axios from "axios";

function VerificationPage({ type }) {
  const [file, setFile] = useState(null);
  const [docId, setDocId] = useState("");
  const [result, setResult] = useState(null);
  const [verifying, setVerifying] = useState(false);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setResult(null);
  };

  const handleVerify = async () => {
    if (!file || !docId || isNaN(Number(docId))) {
      setResult("Please select a file and provide a valid Document ID.");
      return;
    }
    setVerifying(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const endpoint =
        type === "duck"
          ? `/verify_duck_pdf/${docId}`
          : `/verify_pdf/${docId}`;
      const res = await axios.post(
        `${process.env.REACT_APP_BACKEND_URL}${endpoint}`,
        formData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );
      setResult(
        res.data.valid
          ? "✅ PDF is valid and watermarked."
          : "❌ Invalid or missing watermark."
      );
    } catch (err) {
      setResult("Verification failed: " + (err?.message || "Unknown error"));
    }
    setVerifying(false);
  };

  return (
    <div className="card silky-card shadow fadein">
      <div className="card-body">
        <h4>{type === "duck" ? "Verify Duck Watermarked PDF" : "Verify LexChain PDF"}</h4>
        <div className="mb-3">
          <label>Document ID:</label>
          <input
            type="text"
            className="form-control"
            value={docId}
            onChange={e => setDocId(e.target.value)}
            style={{ maxWidth: 240, display: "inline-block", marginLeft: 8 }}
            placeholder="Enter Document ID"
          />
        </div>
        <div className="mb-3">
          <label>Select PDF file:</label>
          <input type="file" accept=".pdf" onChange={handleFileChange} />
        </div>
        <button
          className="btn silky-btn silky-btn-primary"
          disabled={verifying}
          onClick={handleVerify}
        >
          {verifying ? "Verifying..." : "Verify"}
        </button>
        {result && <div className="mt-3">{result}</div>}
      </div>
    </div>
  );
}

export default VerificationPage;