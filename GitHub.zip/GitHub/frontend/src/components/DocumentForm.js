import React, { useState, useRef } from "react";
import axios from "axios";

/**
 * DocumentForm with automatic date pickers:
 * - For every field whose label or id includes "date", "start", "end", "lease" (case-insensitive), renders a date picker.
 * - Includes a document-wide date picker at the top.
 */
function DocumentForm({ template, setDocument, setDocId, onBack }) {
  // Helper: determine input type for a given field
  const getFieldType = (field) => {
    const txt = (field.label + " " + field.id).toLowerCase();
    if (
      txt.includes("date") ||
      txt.includes("start") ||
      txt.includes("end") ||
      txt.includes("lease")
    ) {
      return "date";
    }
    return "text";
  };

  // Initial field state
  const [fields, setFields] = useState(
    Object.fromEntries(template.fields.map(f => [f.id, ""]))
  );

  // Document-wide date
  const [docDate, setDocDate] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [streamedText, setStreamedText] = useState("");
  const [finished, setFinished] = useState(false);
  const streamedTextRef = useRef("");

  // Field change
  const handleChange = (e, id) => {
    setFields({ ...fields, [id]: e.target.value });
  };

  // Document-wide date change
  const handleDocDateChange = (e) => setDocDate(e.target.value);

  // Form submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    setFinished(false);
    setStreamedText("");
    streamedTextRef.current = "";

    try {
      // Prepare fields object, attach docDate if present
      const requestFields = { ...fields };
      if (docDate) {
        // Try to map to template field if exists
        const docDateField = template.fields.find(f => /document date/i.test(f.label));
        if (docDateField) {
          requestFields[docDateField.id] = docDate;
        }
      }

      const response = await fetch(`${process.env.REACT_APP_BACKEND_URL}/generate/stream`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ template_id: template.id, fields: requestFields }),
      });

      if (!response.ok || !response.body) {
        setError("Generation failed. Please check your input and try again.");
        setLoading(false);
        return;
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let docText = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        docText += chunk;
        streamedTextRef.current += chunk;
        setStreamedText(streamedTextRef.current);
      }

      setFinished(true);

      // Save generated document to backend and get document_id, include docDate
      const saveRes = await axios.post(
        `${process.env.REACT_APP_BACKEND_URL}/document`,
        {
          client_data: Object.values(requestFields).join(", "),
          document_type: template.name,
          generated_text: docText,
          date: docDate || new Date().toISOString().split("T")[0],
        }
      );
      setDocId(saveRes.data.document_id);
      setDocument(docText);
    } catch (err) {
      setError("Streaming failed or document save failed. Please try again.");
    }
    setLoading(false);
  };

  return (
    <form
      className="mt-3 silky-form"
      onSubmit={handleSubmit}
      autoComplete="off"
      style={{
        maxWidth: 380,
        margin: "0 auto",
        fontSize: "0.95rem",
        background: "#f9f9fc",
        borderRadius: 10,
        padding: "18px 18px 10px 18px",
        boxShadow: "0 2px 14px rgba(32,55,120,0.07)",
      }}
    >
      <h5 className="mb-2" style={{ fontSize: "1.13rem" }}>{template.name}</h5>
      <p className="text-muted mb-3" style={{ fontSize: ".95em" }}>{template.description}</p>
      {/* Document-wide date selection */}
      <div className="mb-2">
        <label style={{ fontSize: ".98em" }}>Document Date</label>
        <input
          type="date"
          className="form-control"
          style={{
            padding: "4px 9px",
            fontSize: ".97em",
            height: 30,
            minHeight: 30,
            borderRadius: 6,
          }}
          value={docDate}
          onChange={handleDocDateChange}
          disabled={loading}
        />
      </div>
      {template.fields.map(field => (
        <div className="mb-2" key={field.id}>
          <label style={{ fontSize: ".98em" }}>{field.label}</label>
          <input
            type={getFieldType(field)}
            className="form-control"
            style={{
              padding: "4px 9px",
              fontSize: ".97em",
              height: 30,
              minHeight: 30,
              borderRadius: 6,
            }}
            value={fields[field.id]}
            onChange={e => handleChange(e, field.id)}
            required
            placeholder={getFieldType(field) === "text" ? `Enter ${field.label}` : ""}
            disabled={loading}
          />
        </div>
      ))}
      {error && <div className="text-danger mb-2" style={{ fontSize: ".98em" }}>{error}</div>}
      <div className="d-flex gap-2 mb-2" style={{ marginTop: 8 }}>
        <button className="btn silky-btn silky-btn-primary" type="submit" disabled={loading} style={{ fontSize: ".98em", padding: "4px 18px", borderRadius: 7 }}>
          {loading ? (
            <span>
              <span className="spinner-border spinner-border-sm me-2" role="status" /> Generating...
            </span>
          ) : finished ? "Regenerate" : "Generate Document"}
        </button>
        {onBack && (
          <button className="btn silky-btn silky-btn-outline" type="button" onClick={onBack} disabled={loading} style={{ fontSize: ".98em", padding: "4px 16px", borderRadius: 7 }}>
            Back
          </button>
        )}
      </div>
      <div style={{ minHeight: 24 }}>
        {streamedText && (
          <pre style={{
            background: "#f8f9fa",
            borderRadius: 7,
            padding: 8,
            marginTop: 8,
            fontFamily: "Fira Mono,monospace",
            whiteSpace: "pre-wrap",
            fontSize: 13.5,
            boxShadow: "0 1px 8px rgba(32,55,120,0.06)"
          }}>
            {streamedText}
          </pre>
        )}
      </div>
    </form>
  );
}

export default DocumentForm;
